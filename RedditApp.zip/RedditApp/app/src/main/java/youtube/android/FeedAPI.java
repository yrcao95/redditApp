package youtube.android;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import youtube.android.model.Feed;

public interface FeedAPI {

    String BASE_URL = "https://www.reddit.com/r/";

    @GET("{feed_name}/.rss")
    Call<Feed> getFeed(@Path("feed_name") String feed_name);

    @GET("TheSilphRoad/.rss")
    Call<Feed> getFeed();
}
